var express = require("express");
var bodyParser = require("body-parser");
//Nos devuelve un objeto sobre el que trabajamos
var app = express();

//A todos los archivos estáticos, les añado un prefijo

app.use("/public",express.static('public'));

app.use(bodyParser.json()); //Para peticiones que tengan el formato json
app.use(bodyParser.urlencoded({extended: true}));

app.set("view engine", "jade");

app.get("/", function(req,res){
  res.render("index");
});

app.get("/login",function(req,res){
  res.render("login");
});

app.post("/users",function(req,res){
  console.log("Contraseña: "+ req.body.password);
  console.log("Email: "+ req.body.email);
  res.send("Recibimos tus datos");
});


app.listen(8080);
